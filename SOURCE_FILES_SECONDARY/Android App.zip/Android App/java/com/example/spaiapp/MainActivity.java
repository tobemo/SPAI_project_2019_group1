package com.example.spaiapp;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioRecord;
import android.media.AudioTrack;
import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.io.DataOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.io.RandomAccessFile;
import java.nio.ByteOrder;
import java.util.*;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Arrays;

import static android.media.AudioRecord.READ_BLOCKING;
import static android.media.AudioRecord.READ_NON_BLOCKING;
import static android.media.AudioTrack.WRITE_BLOCKING;

public class MainActivity extends AppCompatActivity {

    private static String TAG = "AudioClient";

    // the server information
    private String SERVER = "192.168.137.1";
    private int PORT = 8888;

    // the audio recording options
    private int resampleIndex = 1;
    private static final int RECORDING_RATE = 44100;
    private static final int CHANNEL = AudioFormat.CHANNEL_IN_MONO;
    private static final int FORMAT = AudioFormat.ENCODING_PCM_FLOAT;

    //private static int BUFFER_SIZE = AudioRecord.getMinBufferSize(RECORDING_RATE, CHANNEL, FORMAT);
    private static int BUFFER_SIZE = 256;
    private float[] buffer;

    private AudioRecord recorder;
    private AudioTrack at;

    int i =0;

    private DatagramSocket socket;
    private DatagramPacket packet;

    private EditText ipet;
    private EditText portet;
    private EditText sampindexet;

    // are we currently sending audio data
    private boolean recording = false;


    @SuppressLint("ClickableViewAccessibility")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        ipet = findViewById(R.id.ipain);
        portet = findViewById(R.id.portin);
        sampindexet = findViewById(R.id.sampfreqin);

        setButtonHandlers();
    }

    private void setButtonHandlers(){
        // the button the user presses to send the audio stream to the server
        Button recordButton = (Button) findViewById(R.id.start_button);
        recordButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startStreamingAudio_v2();
            }
        });

        Button stopButton = (Button) findViewById(R.id.stop_button);
        stopButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                stopRecorder();
            }
        });
    }

    private void resInit(){
        SERVER = ipet.getText().toString();
        PORT = Integer.parseInt(portet.getText().toString());
        resampleIndex = Integer.parseInt(sampindexet.getText().toString());

        buffer = new float[BUFFER_SIZE];
        recorder = new AudioRecord(MediaRecorder.AudioSource.MIC, RECORDING_RATE, CHANNEL, FORMAT, BUFFER_SIZE);

        int intSize = android.media.AudioTrack.getMinBufferSize(RECORDING_RATE, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_FLOAT);
        at = new AudioTrack(AudioManager.STREAM_MUSIC, RECORDING_RATE, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_FLOAT, intSize, AudioTrack.MODE_STREAM);


        try {
            socket = new DatagramSocket(PORT);
        } catch (SocketException e) {
            e.printStackTrace();
        }


    }

    private byte[] floatToByteArray(float[] a){

        //"bytes[]" can be converted to a c++ struct when send over UDP
        byte[] bytes = new byte[4*BUFFER_SIZE + 4];
        byte[] intBytes = ByteBuffer.allocate(4).putInt(resampleIndex).array();

        //Put the floats in the byte struct
        for(int k = 0; k < BUFFER_SIZE; k++){
            byte[] temp = float2ByteArray(a[k]);
            bytes[(k*4)] = temp[3];
            bytes[(k*4)+1] = temp[2];
            bytes[(k*4)+2] = temp[1];
            bytes[(k*4)+3] = temp[0];
        }

        //Add the resampleindex to the byte struct
        bytes[4*BUFFER_SIZE] = intBytes[3];
        bytes[4*BUFFER_SIZE+1] = intBytes[2];
        bytes[4*BUFFER_SIZE+2] = intBytes[1];
        bytes[4*BUFFER_SIZE+3] = intBytes[0];
        return bytes;
    }

    private void startStreamingAudio_v2(){
        recording = true;
        Thread recordThread = new Thread(new Runnable() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void run() {
                try {
                    FileOutputStream wavOut = null;
                    String filePath = Environment.getExternalStorageDirectory() + "/final_demo5.wav";
                    File f = new File(filePath);
                    f.createNewFile();
                    wavOut = new FileOutputStream(f);
                    writeWavHeader(wavOut, (short) 1, RECORDING_RATE, (short) 32);

                    resInit();
                    final InetAddress serverAddress = InetAddress.getByName(SERVER);
                    recorder.startRecording();

                    int i = 0;
                    float[] outBuffer = new float[BUFFER_SIZE];
                    while(recording){
                        int read = recorder.read(buffer, 0 , buffer.length, READ_BLOCKING);

                        if(i>=resampleIndex) {
                            byte[] window = floatToByteArray(outBuffer);
                            byte[] temp = floatToByteArray2(outBuffer);
                            wavOut.write(temp, 0, temp.length);
                            packet = new DatagramPacket(window, window.length, serverAddress, PORT);
                            socket.send(packet);
                            i = 0;
                        }

                        for(int j = 0; j<BUFFER_SIZE/resampleIndex; j++){
                            outBuffer[i*(BUFFER_SIZE/resampleIndex)+j] = buffer[j*resampleIndex];
                        }
                        i++;
                    }
                    wavOut.close();
                    //updateWavHeader(f);
                    return;

                } catch (IllegalStateException | IOException e) {
                    Log.e(TAG, "Exception: " + e);
                }
            }
        });
        recordThread.start();
    }

    private void startDirectPlayback() {
        recording = true;
        Thread recordThread = new Thread(new Runnable() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void run() {
                try {
                    resInit();
                    recorder.startRecording();
                    while(recording){
                        recorder.read(buffer, 0 , BUFFER_SIZE, READ_BLOCKING);
                        if (at!=null) {
                            at.play();
                            //at.write(buffer, 0, buffer.length);
                        }
                    }
                    recorder.stop();
                    recorder.release();
                    at.stop();
                    at.release();
                    return;

                } catch (IllegalStateException e) {
                    Log.e(TAG, "Exception: " + e);
                }
            }
        });
        recordThread.start();
    }

    private void stopRecorder() {
        Log.i(TAG, "Stopping the audio stream");
        //recorder.stop();
        recorder.release();
        recording = false;
        socket.close();
    }

    public static byte [] float2ByteArray(float value){
        return ByteBuffer.allocate(4).putFloat(value).array();
    }

    private static void writeWavHeader(OutputStream out, short channels, int sampleRate, short bitDepth) throws IOException {
        // Convert the multi-byte integers to raw bytes in little endian format as required by the spec
        byte[] littleBytes = ByteBuffer
                .allocate(14)
                .order(ByteOrder.LITTLE_ENDIAN)
                .putShort(channels)
                .putInt(sampleRate)
                .putInt(sampleRate * channels * (bitDepth / 8))
                .putShort((short) (channels * (bitDepth / 8)))
                .putShort(bitDepth)
                .array();

        // Not necessarily the best, but it's very easy to visualize this way
        out.write(new byte[]{
                // RIFF header
                'R', 'I', 'F', 'F', // ChunkID
                0, 0, 0, 0, // ChunkSize (must be updated later)
                'W', 'A', 'V', 'E', // Format
                // fmt subchunk
                'f', 'm', 't', ' ', // Subchunk1ID
                16, 0, 0, 0, // Subchunk1Size
                3, 0, // AudioFormat
                littleBytes[0], littleBytes[1], // NumChannels
                littleBytes[2], littleBytes[3], littleBytes[4], littleBytes[5], // SampleRate
                littleBytes[6], littleBytes[7], littleBytes[8], littleBytes[9], // ByteRate
                littleBytes[10], littleBytes[11], // BlockAlign
                littleBytes[12], littleBytes[13], // BitsPerSample
                // data subchunk
                'd', 'a', 't', 'a', // Subchunk2ID
                0, 0, 0, 0, // Subchunk2Size (must be updated later)
        });
    }

    private byte[] floatToByteArray2(float[] a){

        //"bytes[]" can be converted to a c++ struct when send over UDP
        byte[] bytes = new byte[4*BUFFER_SIZE];

        //Put the floats in the byte struct
        for(int k = 0; k < BUFFER_SIZE; k++){
            byte[] temp = float2ByteArray(a[k]);
            bytes[(k*4)] = temp[3];
            bytes[(k*4)+1] = temp[2];
            bytes[(k*4)+2] = temp[1];
            bytes[(k*4)+3] = temp[0];
        }

        return bytes;
    }
}
